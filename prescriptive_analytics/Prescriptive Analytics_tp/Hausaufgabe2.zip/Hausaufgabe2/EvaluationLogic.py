import numpy 

class EvaluationLogic:    
    def DefineStartEnd(self, currentSolution):    
        #####
        # schedule first job: starts when finished at previous stage
        firstJob = currentSolution.OutputJobs[currentSolution.Permutation[0]]
        firstJob.EndTimes = numpy.cumsum([firstJob.ProcessingTime(x) for x in range(len(firstJob.EndTimes))])
        firstJob.StartTimes[1:] = firstJob.EndTimes[:-1]
        #####
        # schedule further jobs: starts when finished at previous stage and the predecessor is no longer on the considered machine
        for j in range(1,len(currentSolution.Permutation)):
            currentJob = currentSolution.OutputJobs[currentSolution.Permutation[j]]
            previousJob = currentSolution.OutputJobs[currentSolution.Permutation[j-1]]
            # first machine
            currentJob.StartTimes[0] = previousJob.EndTimes[0]
            currentJob.EndTimes[0] = currentJob.StartTimes[0] + currentJob.ProcessingTime(0)
            # other machines
            for i in range(1,len(currentJob.StartTimes)):
                currentJob.StartTimes[i] = max(previousJob.EndTimes[i], currentJob.EndTimes[i-1])
                currentJob.EndTimes[i] = currentJob.StartTimes[i] + currentJob.ProcessingTime(i)
        #####
        # Save Makespan and return Solution
        currentSolution.Makespan = currentSolution.OutputJobs[currentSolution.Permutation[-1]].EndTimes[-1]